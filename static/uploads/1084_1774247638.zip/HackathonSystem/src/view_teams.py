import pandas as pd
from db_connection import get_connection


def view_all_teams():

    conn = get_connection()

    print("\n========== ALL HACKATHON TEAMS ==========\n")

    # Get all hackathons
    hackathons = pd.read_sql("""
        SELECT DISTINCT HACKATHON_PREFERENCE
        FROM HACKATHON_STUDENTS
        ORDER BY HACKATHON_PREFERENCE
    """, conn)

    for hackathon in hackathons['HACKATHON_PREFERENCE']:

        print(f"\n Hackathon: {hackathon}")
        print("-" * 50)

        df = pd.read_sql("""
            SELECT TEAM_ID,
                   STUDENT_ID,
                   ROLE
            FROM HACKATHON_STUDENTS
            WHERE HACKATHON_PREFERENCE = :hack
              AND TEAM_ID IS NOT NULL
            ORDER BY TEAM_ID, ROLE
        """, conn, params={"hack": hackathon})

        if df.empty:
            print("No teams formed.")
            continue

        # Group by team
        teams = df.groupby('TEAM_ID')

        for team_id, members in teams:

            print(f"\nTeam {team_id}")
            print("-----------")

            for _, row in members.iterrows():
                print(f"Student ID: {row['STUDENT_ID']}  |  Role: {row['ROLE']}")

    conn.close()

    print("\n========== END ==========\n")


if __name__ == "__main__":
    view_all_teams()
