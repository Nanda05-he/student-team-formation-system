import pandas as pd
from db_connection import get_connection

def insert_students():
    # Load CSV
    df = pd.read_csv("hackathon_students_1000_unique.csv")

    conn = get_connection()
    cursor = conn.cursor()

    for _, row in df.iterrows():
        cursor.execute("""
            INSERT INTO HACKATHON_STUDENTS
            (STUDENT_NAME, EMAIL_ID, COLLEGE_NAME,
             HACKATHON_PREFERENCE,
             FRONTEND_SKILL, BACKEND_SKILL,
             COMMUNICATION_SKILL, LEADERSHIP_SKILL)
            VALUES (:1,:2,:3,:4,:5,:6,:7,:8)
        """, (
            row['Student_Name'],
            row['Email_ID'],
            row['College_Name'],
            row['Hackathon_Preference'],
            row['Frontend_Skill'],
            row['Backend_Skill'],
            row['Communication_Skill'],
            row['Leadership_Skill']
        ))

    conn.commit()
    cursor.close()
    conn.close()

    print("Students Inserted Successfully ")


if __name__ == "__main__":
    insert_students()
