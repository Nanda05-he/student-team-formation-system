from db_connection import get_connection

def check_student_team():

    email = input("Enter your Email ID: ")

    conn = get_connection()
    cursor = conn.cursor()

    # Step 1: Fetch student info
    cursor.execute("""
        SELECT STUDENT_ID,
               HACKATHON_PREFERENCE,
               CLUSTER_ID,
               TEAM_ID,
               ROLE
        FROM HACKATHON_STUDENTS
        WHERE EMAIL_ID = :1
    """, (email,))

    result = cursor.fetchone()

    if not result:
        print("No student found with this email.")
        return

    # ✅ unpack 5 values now
    student_id, hackathon, cluster_id, team_id, role = result

    print("\n========== STUDENT DETAILS ==========")
    print(f"Student ID : {student_id}")
    print(f"Hackathon  : {hackathon}")
    print(f"Cluster    : {cluster_id}")
    print(f"Role       : {role}")
    print(f"Team ID    : {team_id}")

    if team_id is None:
        print("\nYou are not assigned to a team yet.")
        return

    # Step 2: Fetch teammates
    cursor.execute("""
        SELECT STUDENT_ID, EMAIL_ID, CLUSTER_ID, ROLE
        FROM HACKATHON_STUDENTS
        WHERE HACKATHON_PREFERENCE = :1
        AND TEAM_ID = :2
        ORDER BY CLUSTER_ID
    """, (hackathon, team_id))

    teammates = cursor.fetchall()

    print("\n========== YOUR TEAM MEMBERS ==========")
    for member in teammates:
        print(f"Student ID: {member[0]} | Email: {member[1]} | Cluster: {member[2]} | Role: {member[3]}")

    cursor.close()
    conn.close()


if __name__ == "__main__":
    check_student_team()
