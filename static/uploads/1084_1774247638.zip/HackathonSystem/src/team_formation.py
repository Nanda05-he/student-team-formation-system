


import pandas as pd
from db_connection import get_connection


def form_teams():

    conn = get_connection()
    cursor = conn.cursor()

    print("\n========== TEAM FORMATION STARTED ==========\n")

    # Reset teams
    cursor.execute("UPDATE HACKATHON_STUDENTS SET TEAM_ID = NULL")
    conn.commit()

    hackathons = pd.read_sql("""
        SELECT DISTINCT HACKATHON_PREFERENCE
        FROM HACKATHON_STUDENTS
    """, conn)

    team_id = 1

    for hackathon in hackathons['HACKATHON_PREFERENCE']:

        print(f"\nProcessing Hackathon: {hackathon}")

        df = pd.read_sql("""
            SELECT STUDENT_ID, ROLE, CLUSTER_ID
            FROM HACKATHON_STUDENTS
            WHERE HACKATHON_PREFERENCE = :hack
        """, conn, params={"hack": hackathon})

        if df.empty:
            continue

        # ===============================
        # STAGE 1 — CLUSTER BASED TEAMS
        # ===============================

        clusters = df['CLUSTER_ID'].unique()

        cluster_groups = {
            c: df[df['CLUSTER_ID'] == c].to_dict('records')
            for c in clusters
        }

        teams_cluster = 0

        while all(cluster_groups[c] for c in clusters):

            team_members = []

            for c in clusters:
                team_members.append(cluster_groups[c].pop())

            for member in team_members:
                cursor.execute("""
                    UPDATE HACKATHON_STUDENTS
                    SET TEAM_ID = :1
                    WHERE STUDENT_ID = :2
                """, (team_id, int(member['STUDENT_ID'])))

            team_id += 1
            teams_cluster += 1

        print(f"Cluster Teams formed: {teams_cluster}")

        # ===============================
        # STAGE 2 — SKILL BASED TEAMS
        # ===============================

        remaining_df = pd.read_sql("""
            SELECT STUDENT_ID, ROLE
            FROM HACKATHON_STUDENTS
            WHERE HACKATHON_PREFERENCE = :hack
            AND TEAM_ID IS NULL
        """, conn, params={"hack": hackathon})

        frontend = remaining_df[remaining_df['ROLE'] == 'Frontend Developer'].to_dict('records')
        backend = remaining_df[remaining_df['ROLE'] == 'Backend Developer'].to_dict('records')
        communication = remaining_df[remaining_df['ROLE'] == 'Communication Lead'].to_dict('records')
        manager = remaining_df[remaining_df['ROLE'] == 'Project Manager'].to_dict('records')

        teams_skill = 0

        while frontend and backend and communication and manager:

            team_members = [
                frontend.pop(),
                backend.pop(),
                communication.pop(),
                manager.pop()
            ]

            for member in team_members:
                cursor.execute("""
                    UPDATE HACKATHON_STUDENTS
                    SET TEAM_ID = :1
                    WHERE STUDENT_ID = :2
                """, (team_id, int(member['STUDENT_ID'])))

            team_id += 1
            teams_skill += 1

        print(f"Skill Teams formed: {teams_skill}")

    conn.commit()
    cursor.close()
    conn.close()

    print("\n TEAMS FORMED SUCCESSFULLY")


if __name__ == "__main__":
    form_teams()
