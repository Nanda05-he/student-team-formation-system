import pandas as pd
from db_connection import get_connection

def view_teams():

    conn = get_connection()

    hackathons = pd.read_sql("""
        SELECT DISTINCT HACKATHON_PREFERENCE
        FROM HACKATHON_STUDENTS
        ORDER BY HACKATHON_PREFERENCE
    """, conn)

    for hackathon in hackathons['HACKATHON_PREFERENCE']:

        print(f"\n Hackathon: {hackathon}")
        print("-" * 50)

        df = pd.read_sql("""
            SELECT TEAM_ID,
                   STUDENT_NAME,
                   EMAIL_ID,
                   ROLE
            FROM HACKATHON_STUDENTS
            WHERE HACKATHON_PREFERENCE = :hack
              AND TEAM_ID IS NOT NULL
            ORDER BY TEAM_ID, ROLE
        """, conn, params={"hack": hackathon})

        if df.empty:
            print("No teams formed.")
            continue

        for team_id in sorted(df['TEAM_ID'].unique()):

            print(f"\nTeam {team_id}")
            print("-----------")

            team_members = df[df['TEAM_ID'] == team_id]

            for _, row in team_members.iterrows():
                print(
                    f"Name: {row['STUDENT_NAME']} | "
                    f"Email: {row['EMAIL_ID']} | "
                    f"Role: {row['ROLE']}"
                )

    conn.close()


if __name__ == "__main__":
    view_teams()
